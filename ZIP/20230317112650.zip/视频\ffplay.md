
https://linux.die.net/man/1/ffplay

## 源代码

- https://github.com/FFmpeg/FFmpeg/blob/master/fftools/ffplay.c
- https://ffmpeg.org/doxygen/trunk/ffplay_8c_source.html