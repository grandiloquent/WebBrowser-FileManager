# ffmpeg|笔记
        
## 格式转换

```
ffmpeg -i 0.mov o.mp4
ffmpeg -ss 78 -t 1 -i 2.mp4 -vsync 0 -f image2 %06d.png
ffmpeg -i 0.mp4 -map 0:1 0.mp3
```

## 剪辑

```
ffmpeg -ss 5 -i 0.mp4 1.mp4        
ffmpeg -ss 69 -t 30 -i 0.mp4 -map 0:1 0.mp3
```

## 录屏

```
ffmpeg -hide_banner -rtbufsize 150M -f gdigrab -framerate 30 -offset_x 0 -offset_y 0 -video_size 1280x720 -draw_mouse 1 -i desktop -c:v libx264 -r 30 -preset ultrafast -tune zerolatency -crf 28 -pix_fmt yuv420p -movflags +faststart -y 1.mp4
```
    
## 合并

```
ffmpeg -i 1.mp4 -i 1.mov -filter_complex "[0:0][1:0]overlay=enable='between(t,1,9)'[out]" -shortest -map [out] -map 0:1 -pix_fmt yuv420p -c:a copy -c:v libx264 -crf 18 -y 2.mp4
```


```
ffmpeg -ss 00:00:01.000 ^
 -i 4.mp4 ^
-vframes 1 ^
output.png
```

```
ffmpeg -i 0.mp4 ^
-vf crop=400:720:440:0,scale=720:1280,setsar=1 ^
-c:a copy 1.mp4
ffmpeg -y -i 1.mp4 -itsoffset 1 -i 1.mp3 -map 0:0 -map 1:0 -c:v copy -preset ultrafast -async 1 2.mp4

ffmpeg -i 0.mp4 -vf crop=400:720:440:0,scale=720:1280,setsar=1 -c:a copy 1.mp4 2> NUL
ffmpeg -i 1.mp4 -i 1.mp3 -filter_complex "[0:a]volume=1[a0]; [1:a]volume=1.98,adelay=1000|1000[a1]; [a0][a1]amix=inputs=2[a]" -map 0:v -map "[a]" -c:v copy -c:a mp3 2.mp4 -y 2> NUL
ffmpeg -i 2.mp4 -i 720X1280.png -filter_complex "[0:v][1:v] overlay=0:0:enable='between(t,0,.5)'" -pix_fmt yuv420p -c:a copy 3.mp4 -y 2> NUL

ffmpeg -i 0.mp4 -vf "scale=w=720:h=1280:force_original_aspect_ratio=1,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1" -c:a copy 1.mp4 -y 2> NUL
ffmpeg -i 1.mp4 -i 1.mp3 -filter_complex "[0:a]volume=1[a0]; [1:a]volume=1.98,adelay=1000|1000[a1]; [a0][a1]amix=inputs=2[a]" -map 0:v -map "[a]" -c:v copy -c:a mp3 2.mp4 -y 2> NUL
ffmpeg -i 2.mp4 -i 720X1280.png -filter_complex "[0:v][1:v] overlay=0:0:enable='between(t,0,.5)'" -pix_fmt yuv420p -c:a copy 3.mp4 -y 2> NUL

ffmpeg -ss 5 -i 0.mp4 -vf "scale=w=720:h=1280:force_original_aspect_ratio=1,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1" -c:a copy output.mp4 -y 2>NUL

```

```
ffmpeg -ss 5 -t 20 -i 3.mp4 ^
-vf crop=400:720:440:0,scale=720:1280,setsar=1 ^
-c:a copy output.mp4


```


```
ffmpeg -i 4.mp4 ^
-vf crop=720:720:280:0,pad=720:1280:0:280:black,setsar=1 ^
-c:a copy output.mp4
```

```
ffmpeg -y -i output.mp4 ^
-itsoffset 1 -i 2.mp3 ^
-map 0:0 ^
-map 1:0 ^
-c:v copy ^
-preset ultrafast ^
-async 1 out.mp4
```

```
ffmpeg -i out.mp4 -i 720X1280.png ^
-filter_complex "[0:v][1:v] overlay=0:0:enable='between(t,0,.1)'" ^
-pix_fmt yuv420p -c:a copy ^
1.mp4
```

ffmpeg -i 6.mp4 -af volume=.5 -vcodec copy 66.mp4


```
ffmpeg -y -i 1.mp4 ^
-itsoffset 25.13 -i 721.mp3 ^
-map 0:0 ^
-map 1:0 ^
-c:v copy ^
-preset ultrafast ^
-async 1 2.mp4
```


```
ffmpeg -i 0.mp4 -vf "scale=w=720:h=1280:force_original_aspect_ratio=1,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1" -c:a copy 1.mp4 -y

ffmpeg -y -i 1.mp4 ^
-itsoffset 1 -i 1.mp3 ^
-map 0:0 ^
-map 1:0 ^
-c:v copy ^
-preset ultrafast ^
-async 1 2.mp4

ffmpeg -i 2.mp4 -i 720X1280.png ^
-filter_complex "[0:v][1:v] overlay=0:0:enable='between(t,0,.5)'" ^
-pix_fmt yuv420p -c:a copy ^
3.mp4 -y
```

```
ffmpeg -i 1.mp4 -i 1.mp3 -filter_complex "[0:a]volume=0.5[a0]; [1:a]volume=1.98,adelay=3400|3400[a1]; [a0][a1]amix=inputs=2[a]" -map 0:v -map "[a]" -c:v copy -c:a mp3 2.mp4 -y
ffmpeg -i 2.mp4 -i 2.mp3 -filter_complex "[0:a]volume=1.98[a0]; [1:a]volume=1.98,adelay=37534|37534[a1]; [a0][a1]amix=inputs=2[a]" -map 0:v -map "[a]" -c:v copy -c:a mp3 3.mp4 -y
```

//  -f image2 

```javascript
ffmpeg -loop 1 -i 1.jpg -framerate 1/10 -filter:v "scale=eval=frame:w=720:h=1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2:black" -vcodec libx264  -t 10 -crf 18  -pix_fmt yuv420p test.mp4 -y 

2> NUL
```


- [crop](https://ffmpeg.org/ffmpeg-filters.html#crop)
- [pad](https://ffmpeg.org/ffmpeg-filters.html#pad-1)
- [Main options](https://ffmpeg.org/ffmpeg.html#toc-Main-options)
- [下载](https://ffmpeg.org/download.html)
 
## 下载

[GitHub 自动多平台编译](https://github.com/BtbN/FFmpeg-Builds/releases)

## ffmpeg

```shell
// 快速剪辑
ffmpeg -i 2.mp4 -vcodec copy -acodec copy -ss 00:00:14 -to 00:00:59 3.mp4
// 调整尺寸
ffmpeg -i 3.mp4 -filter:v "scale=iw*min(576/iw\,1024/ih):ih*min(576/iw\,1024/ih), pad=576:1024:(576-iw*min(576/iw\,1024/ih))/2:(1024-ih*min(576/iw\,1024/ih))/2" 5.mp4
// 嵌入字幕
ffmpeg -i 3.mp4 -f srt -i 3.srt -c:v copy -c:a copy -c:s mov_text 5.mp4
// 提取音频
ffmpeg -vn -sn -dn -i 01.mp4 -codec:a libmp3lame -qscale:a 4 01.mp3
// 播放视频
ffplay -vf "drawtext=text='%{pts\:hms}':fontsize=48:box=1:x=(w-tw)/2:y=300" 2.mp4  -ss 00:01:40 
```


## 更多

- https://github.com/FFmpeg/FFmpeg
- https://gist.github.com/gmolveau/a75679291028fcb22548a61da92377e7
- https://superuser.com/questions/1463710/convert-mp4-to-mp3-with-ffmpeg

ffmpeg -i 0.mp4 -vf "scale=w=720:h=1280:force_original_aspect_ratio=1,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1" -c:a copy 1.mp4 -y 2> NUL

- https://ffmpeg.org/ffmpeg.html#toc-Main-options
- https://ffmpeg.org/ffmpeg.html#filter_005foption
        
ffmpeg -i audio.mp3 -i video.mp4 -filter_complex \
"[0:a][1:a]amerge,pan=stereo|c0<c0+c2|c1<c1+c3[a]" \
-map 1:v -map "[a]" -c:v copy -c:a aac -shortest output.mp4

https://superuser.com/questions/712862/ffmpeg-add-background-audio-to-video-but-not-completely-muting-the-original-audi
        